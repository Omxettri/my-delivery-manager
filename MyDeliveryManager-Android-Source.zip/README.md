# My Delivery Manager (Android source project)

A single-driver Android app prototype with:
- Manual client entry (name, WhatsApp phone number, delivery address)
- Daily delivery list and pending/completed counts
- WhatsApp click-to-chat using an editable message template
- Google Maps search/navigation handoff
- Local delivery history grouped by date
- Local Room database; no account, server, analytics, or cloud sync

## Build in Android Studio
1. Install Android Studio with Android SDK Platform 35.
2. Open this folder (`MyDeliveryManager`) in Android Studio.
3. Allow Gradle sync to complete.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select Run to install the debug app.
6. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes / limitations
- This is source code, not a prebuilt or tested APK.
- WhatsApp opens a prefilled message; the user must review and tap Send.
- Phone numbers should include country code, e.g. 9715XXXXXXXX, without spaces.
- Location opens Google Maps using the address text; precise coordinates and route optimization are not included.
- Entries are saved locally in Room. Android app data is removed if the app is uninstalled or its storage is cleared. Export/backup is not implemented yet.
- The message template currently remains in memory for the active app session; persistent template settings are a next improvement.
