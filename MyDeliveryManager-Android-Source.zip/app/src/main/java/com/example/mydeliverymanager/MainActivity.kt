package com.example.mydeliverymanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.mydeliverymanager.data.AppDatabase
import com.example.mydeliverymanager.data.Delivery
import com.example.mydeliverymanager.data.DeliveryDao
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).deliveryDao()
        setContent {
            val vm: DeliveryViewModel = viewModel(factory = DeliveryViewModel.Factory(dao))
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DeliveryScreen(vm)
                }
            }
        }
    }
}

class DeliveryViewModel(private val dao: DeliveryDao) : ViewModel() {
    val deliveries = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun add(name: String, phone: String, address: String) {
        viewModelScope.launch {
            dao.insert(Delivery(
                clientName = name.trim(),
                phone = phone.filter { it.isDigit() || it == '+' },
                address = address.trim(),
                deliveryDate = LocalDate.now().toString()
            ))
        }
    }
    fun toggle(item: Delivery) = viewModelScope.launch { dao.update(item.copy(completed = !item.completed)) }
    fun delete(item: Delivery) = viewModelScope.launch { dao.delete(item.id) }

    class Factory(private val dao: DeliveryDao) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = DeliveryViewModel(dao) as T
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryScreen(vm: DeliveryViewModel) {
    val context = LocalContext.current
    val all by vm.deliveries.collectAsStateWithLifecycle()
    val today = LocalDate.now().toString()
    val todays = all.filter { it.deliveryDate == today }
    val history = all.filter { it.deliveryDate != today }.groupBy { it.deliveryDate }.toSortedMap(compareByDescending { it })
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var template by remember { mutableStateOf("Hello {name}, I am on my way to deliver your order. Thank you.") }
    var showTemplate by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val done = todays.count { it.completed }

    Scaffold(topBar = {
        TopAppBar(title = {
            Column {
                Text("My Delivery Manager", fontWeight = FontWeight.Bold)
                Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy")),
                    style = MaterialTheme.typography.labelSmall)
            }
        }, actions = {
            TextButton(onClick = { showTemplate = !showTemplate }) { Text("Message") }
        })
    }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("TOTAL", todays.size.toString())
                        Stat("COMPLETED", done.toString())
                        Stat("PENDING", (todays.size - done).toString())
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("Add a client", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(name, { name = it }, label = { Text("Client name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(phone, { phone = it }, label = { Text("WhatsApp number with country code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(address, { address = it }, label = { Text("Delivery address / location") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                if (name.isNotBlank() && phone.count { it.isDigit() } >= 7 && address.isNotBlank()) {
                                    vm.add(name, phone, address); name = ""; phone = ""; address = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = name.isNotBlank() && phone.count { it.isDigit() } >= 7 && address.isNotBlank()
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp)); Text("Add to today's list")
                        }
                    }
                }
            }
            if (showTemplate) {
                item {
                    Card {
                        Column(Modifier.padding(14.dp)) {
                            Text("WhatsApp message template", fontWeight = FontWeight.Bold)
                            OutlinedTextField(template, { template = it }, modifier = Modifier.fillMaxWidth(),
                                supportingText = { Text("Use {name} to insert the client's name.") })
                        }
                    }
                }
            }
            item { Text("Today's deliveries", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            if (todays.isEmpty()) item { Text("No deliveries added yet. Add your first client above.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(todays, key = { it.id }) { item ->
                DeliveryCard(
                    item = item,
                    onWhatsApp = {
                        val digits = item.phone.filter { it.isDigit() }
                        val msg = template.replace("{name}", item.clientName)
                        val uri = Uri.parse("https://wa.me/$digits?text=${Uri.encode(msg)}")
                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                    },
                    onMap = {
                        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(item.address)}")
                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                    },
                    onToggle = { vm.toggle(item) },
                    onDelete = { vm.delete(item) }
                )
            }
            item {
                OutlinedButton(onClick = { showHistory = !showHistory }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (showHistory) "Hide delivery history" else "Show delivery history (${history.values.sumOf { it.size }})")
                }
            }
            if (showHistory) {
                if (history.isEmpty()) item { Text("No previous delivery history yet.") }
                history.forEach { (date, entries) ->
                    item { Text(date, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    items(entries, key = { it.id }) { item ->
                        DeliveryCard(item, onWhatsApp = {
                            val digits = item.phone.filter { it.isDigit() }
                            val msg = template.replace("{name}", item.clientName)
                            context.startActivity(Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://wa.me/$digits?text=${Uri.encode(msg)}")))
                        }, onMap = {
                            context.startActivity(Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(item.address)}")))
                        }, onToggle = { vm.toggle(item) }, onDelete = { vm.delete(item) })
                    }
                }
            }
            item {
                Text("Your delivery data is stored locally on this phone. No account or cloud sync is used.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun DeliveryCard(
    item: Delivery,
    onWhatsApp: () -> Unit,
    onMap: () -> Unit,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.clientName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(item.phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                AssistChip(onClick = onToggle, label = { Text(if (item.completed) "Completed" else "Pending") },
                    leadingIcon = { Icon(Icons.Default.Check, contentDescription = null) })
            }
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(5.dp))
                Text(item.address, style = MaterialTheme.typography.bodyMedium)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Button(onClick = onWhatsApp, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Message, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("WhatsApp")
                }
                OutlinedButton(onClick = onMap, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.LocationOn, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Navigate")
                }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete delivery") }
            }
        }
    }
}
