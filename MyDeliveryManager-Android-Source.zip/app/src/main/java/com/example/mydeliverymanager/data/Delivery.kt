package com.example.mydeliverymanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deliveries")
data class Delivery(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientName: String,
    val phone: String,
    val address: String,
    val deliveryDate: String,
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
