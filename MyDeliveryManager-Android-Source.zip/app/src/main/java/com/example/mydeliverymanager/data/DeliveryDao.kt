package com.example.mydeliverymanager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DeliveryDao {
    @Query("SELECT * FROM deliveries ORDER BY deliveryDate DESC, createdAt ASC")
    fun observeAll(): Flow<List<Delivery>>

    @Insert
    suspend fun insert(delivery: Delivery)

    @Update
    suspend fun update(delivery: Delivery)

    @Query("DELETE FROM deliveries WHERE id = :id")
    suspend fun delete(id: Long)
}
